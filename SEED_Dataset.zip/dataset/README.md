# SPCC 2026 multi-tool 2-to-4 dataset

打包日期：2026-09-30（Asia/Shanghai）

## 数据内容

- `refined_data_multi_tool_2to4.tar.gz`
  - 原始目录：`/models/Qwen/lyq_jsac_2026_03_17/bisai/data_new/refined_data_multi_tool_2to4`
  - 内容：2,305 个 JSON sample 文件
- `refined_tool_multi_tool_2to4.tar.gz`
  - 原始目录：`/models/Qwen/lyq_jsac_2026_03_17/bisai/data_new/refined_tool_multi_tool_2to4`
  - 内容：2,000 个 JSON tool 文件
- `SHA256SUMS.txt`
  - 两个归档文件的 SHA-256 校验值

## 解压方法

Linux、macOS 或支持 `tar` 的 Windows 环境：

```bash
tar -xzf refined_data_multi_tool_2to4.tar.gz
tar -xzf refined_tool_multi_tool_2to4.tar.gz
```

## 完整性校验

```bash
sha256sum -c SHA256SUMS.txt
```

本归档由服务器上的原始数据目录直接生成，未修改数据文件内容。
